"""
Universal Databricks MCP Client

THE CORE INTEGRATION - This ONE file talks to ALL Databricks MCP servers!

Used by:
- CLI (demos/01-cli/)
- Claude Desktop (demos/04-claude/)
- Slack bot (demos/02-slack/)
- Teams bot (demos/03-teams/)

This is the M+N solution: ONE integration, MULTIPLE platforms!
"""

from typing import Optional, Dict, Any
from databricks.sdk import WorkspaceClient
from databricks_mcp import DatabricksMCPClient
import logging

logger = logging.getLogger(__name__)


class UniversalMCPClient:
    """
    The MAGIC: This ONE class talks to ALL Databricks MCP servers.
    
    Supports:
    - Genie (analytics)
    - Vector Search (RAG)
    - Unity Catalog Functions (actions)
    
    Same query() method works for all three!
    
    Example:
        client = UniversalMCPClient(workspace_client)
        
        # Query Genie
        result = await client.ask_genie(space_id, "What was revenue?")
        
        # Search docs
        docs = await client.search_docs(index_id, "MCP tutorial")
        
        # Execute function
        output = await client.call_function(func_name, {"param": "value"})
    """
    
    def __init__(self, workspace_client: WorkspaceClient):
        """
        Initialize with authenticated workspace client.
        
        Args:
            workspace_client: WorkspaceClient with OAuth or PAT auth
        """
        self.workspace_client = workspace_client
        logger.info("✅ Universal MCP Client initialized")
    
    async def query(
        self, 
        server_url: str, 
        tool_name: str, 
        arguments: Dict[str, Any]
    ) -> str:
        """
        Universal query method - works with ANY MCP server!
        
        This is the breakthrough: SAME method for Genie, Vector Search, UC Functions.
        Only the server_url and tool_name change - the protocol is identical.
        
        Args:
            server_url: MCP server endpoint
            tool_name: Tool to call (e.g., "ask_question", "similarity_search")
            arguments: Tool-specific arguments
            
        Returns:
            Response text from MCP server
            
        Examples:
            # Query Genie
            await query(
                "https://xxx.databricks.com/api/2.0/mcp/genie/space123",
                "ask_question",
                {"question": "What was revenue?"}
            )
            
            # Search docs (Vector Search)
            await query(
                "https://xxx.databricks.com/api/2.0/mcp/vector-search/catalog/schema",
                "similarity_search",
                {"query": "How to deploy?", "num_results": 3}
            )
            
            # Execute function (UC Functions)
            await query(
                "https://xxx.databricks.com/api/2.0/mcp/functions/catalog/schema",
                "execute",
                {"param1": "value1"}
            )
        """
        try:
            logger.info(f"🔍 Querying {tool_name} on {server_url}")
            
            # Create MCP client for this server
            mcp_client = DatabricksMCPClient(
                server_url=server_url,
                workspace_client=self.workspace_client
            )
            
            # For Genie, the tool name might be dynamically generated
            # Try to discover tools if the tool_name doesn't work
            if tool_name.startswith("ask_question") or tool_name == "ask_question":
                # Try to discover the actual tool name
                try:
                    tools = mcp_client.list_tools()
                    # Look for query_space tool
                    query_tool = next((t for t in tools if t.name.startswith("query_space")), None)
                    if query_tool:
                        tool_name = query_tool.name
                        logger.info(f"🔄 Discovered tool name: {tool_name}")
                except Exception:
                    # If discovery fails, try constructing the name from space_id in URL
                    if "/mcp/genie/" in server_url:
                        space_id = server_url.split("/mcp/genie/")[-1]
                        tool_name = f"query_space_{space_id}"
                        logger.info(f"🔄 Using constructed tool name: {tool_name}")
            
            # For Vector Search and UC Functions, discover tool names dynamically
            # Vector Search tools are named like: catalog__schema__index_name
            # UC Function tools are named like: catalog__schema__function_name
            if tool_name in ["similarity_search", "execute"] or "__" in tool_name:
                try:
                    tools = mcp_client.list_tools()
                    if tools:
                        # If tool_name contains __, try to match it exactly
                        if "__" in tool_name:
                            matched_tool = next((t for t in tools if t.name == tool_name), None)
                            if matched_tool:
                                tool_name = matched_tool.name
                                logger.info(f"🔄 Matched tool name: {tool_name}")
                            else:
                                # Fallback: use first tool if exact match fails
                                tool_name = tools[0].name
                                logger.info(f"🔄 Using first available tool: {tool_name}")
                        else:
                            # Use the first available tool (for Vector Search or when function name not provided)
                            tool_name = tools[0].name
                            logger.info(f"🔄 Discovered tool name: {tool_name}")
                except Exception as e:
                    logger.warning(f"⚠️ Could not discover tool name, using: {tool_name}")
                    logger.debug(f"Error: {str(e)}")
            
            # Execute query via MCP protocol
            # call_tool is synchronous, run it in thread pool to avoid blocking
            import asyncio
            result = await asyncio.to_thread(mcp_client.call_tool, tool_name, arguments)
            
            # Extract response
            if result.content and len(result.content) > 0:
                response_text = result.content[0].text
                logger.info(f"✅ Got response ({len(response_text)} chars)")
                return response_text
            else:
                logger.warning("⚠️ Empty response from MCP server")
                return "No response received"
                    
        except Exception as e:
            error_msg = str(e)
            logger.error(f"❌ MCP query failed: {error_msg}")
            import traceback
            full_traceback = traceback.format_exc()
            logger.debug(full_traceback)
            # Try to extract more details from the exception
            if hasattr(e, '__cause__') and e.__cause__:
                error_msg += f"\nCause: {str(e.__cause__)}"
            return f"Error: {error_msg}"
    
    # Convenience methods for each data source
    # These just wrap query() with the right URLs and arguments
    
    async def ask_genie(
        self, 
        space_id: str, 
        question: str, 
        conversation_id: Optional[str] = None
    ) -> tuple[str, str]:
        """
        Query Genie for analytics.
        
        Args:
            space_id: Genie space ID
            question: Natural language question
            conversation_id: Optional conversation ID for multi-turn context
            
        Returns:
            (response_text, conversation_id)
        """
        from shared.config import DATABRICKS_HOST
        
        server_url = f"{DATABRICKS_HOST}/api/2.0/mcp/genie/{space_id}"
        
        # The actual tool name is dynamically generated: query_space_{space_id}
        tool_name = f"query_space_{space_id}"
        
        # Genie MCP uses "query" parameter, not "question"
        arguments = {"query": question}
        if conversation_id:
            arguments["conversation_id"] = conversation_id
        
        # Uses the universal query() method!
        response = await self.query(server_url, tool_name, arguments)
        
        # For simplicity, generate conversation ID
        # In production, extract from result metadata
        new_conv_id = conversation_id or f"conv-{hash(question)}"
        
        return response, new_conv_id
    
    async def search_docs(
        self, 
        index_id: str, 
        query: str, 
        num_results: int = 3
    ) -> str:
        """
        Search documentation using Vector Search.
        
        Args:
            index_id: Vector Search index ID (can be full name like "catalog.schema.index" 
                     or just catalog.schema - catalog and schema will be extracted)
            query: Search query
            num_results: Number of results to return
            
        Returns:
            Formatted search results
        """
        from shared.config import DATABRICKS_HOST
        
        # Extract catalog and schema from index_id
        # Format: catalog.schema.index or catalog.schema
        parts = index_id.split('.')
        if len(parts) >= 2:
            catalog = parts[0]
            schema = parts[1]
            index_name = parts[2] if len(parts) > 2 else None
        else:
            raise ValueError(f"Invalid index_id format: {index_id}. Expected 'catalog.schema' or 'catalog.schema.index'")
        
        # Correct URL format: /api/2.0/mcp/vector-search/{catalog}/{schema}
        server_url = f"{DATABRICKS_HOST}/api/2.0/mcp/vector-search/{catalog}/{schema}"
        
        # The tool name is dynamically generated: catalog__schema__index_name
        # We'll discover it, but if index name is provided, construct it
        if index_name:
            # Convert catalog.schema.index to catalog__schema__index format
            tool_name = f"{catalog}__{schema}__{index_name}"
        else:
            # Use "similarity_search" as placeholder - will be discovered
            tool_name = "similarity_search"
        
        arguments = {
            "query": query,
            "num_results": num_results
        }
        
        # Uses the SAME query() method!
        return await self.query(server_url, tool_name, arguments)
    
    async def call_function(
        self, 
        function_name: str, 
        parameters: Dict[str, Any]
    ) -> str:
        """
        Execute Unity Catalog Function.
        
        Args:
            function_name: Fully qualified function name (catalog.schema.function)
                          catalog and schema will be extracted for the URL
                          The actual tool name will be discovered dynamically
            parameters: Function parameters
            
        Returns:
            Function execution result
        """
        from shared.config import DATABRICKS_HOST
        
        # Extract catalog and schema from function_name
        # Format: catalog.schema.function
        parts = function_name.split('.')
        if len(parts) >= 2:
            catalog = parts[0]
            schema = parts[1]
            function = parts[2] if len(parts) > 2 else None
        else:
            raise ValueError(f"Invalid function_name format: {function_name}. Expected 'catalog.schema.function'")
        
        # Correct URL format: /api/2.0/mcp/functions/{catalog}/{schema}
        server_url = f"{DATABRICKS_HOST}/api/2.0/mcp/functions/{catalog}/{schema}"
        
        # The tool name is dynamically generated: catalog__schema__function_name
        # We'll discover it, but if function name is provided, construct it
        if function:
            # Convert catalog.schema.function to catalog__schema__function format
            tool_name = f"{catalog}__{schema}__{function}"
        else:
            # Use "execute" as placeholder - will be discovered
            tool_name = "execute"
        
        # Uses the SAME query() method again!
        return await self.query(server_url, tool_name, parameters)


def create_mcp_client() -> UniversalMCPClient:
    """
    Factory function to create MCP client with proper auth.
    
    Returns:
        Configured UniversalMCPClient or MockMCPClient (if USE_MOCK_MCP=true)
    """
    from shared.config import USE_MOCK_MCP, get_workspace_client
    
    if USE_MOCK_MCP:
        logger.info("🧪 Creating MOCK MCP client")
        from shared.mock_mcp_client import MockMCPClient
        return MockMCPClient()
    
    workspace_client = get_workspace_client()
    return UniversalMCPClient(workspace_client)

